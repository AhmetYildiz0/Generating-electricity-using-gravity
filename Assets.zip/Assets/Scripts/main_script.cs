using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class main_script : MonoBehaviour
{
	public GameObject template;
	
	[Range(1, 30)]
    public int generatorNumber = 1;
	private int generatorNumber_temp;
	
	[Range(1, 5)]
    public int generatorSplits = 1;
	private int generatorSplits_temp;
	
    public bool isDouble = true;
	private bool isDouble_temp;
	
    private GameObject[] generators = new GameObject[0];
    // Start is called before the first frame update
    void Start()    {
		generators = new GameObject[generatorNumber];
        generatorNumber_temp = generatorNumber;
		generatorSplits_temp = generatorSplits;
		isDouble_temp = isDouble;
		create_generator();
    }
	
	void create_generator()	{
		
		for (int z = 0; z < generators.Length; z++)
		{
			Destroy(generators[z]);
		}
		generators = new GameObject[generatorNumber];
		if(generatorSplits > generatorNumber)
		{
			generatorSplits = generatorNumber;
		}
		float animationOffset = (1/((float)generatorNumber/(float)generatorSplits));
		for (int z = 0; z < generators.Length; z++)
        {
			generators[z] = Instantiate(template, new Vector3(0,0,z * -70), Quaternion.identity);
			generators[z].transform.SetParent(transform, false);
			generators[z].transform.GetChild(0).gameObject.GetComponent<Animator>().Play("generate", 0, animationOffset * z);
			generators[z].transform.GetChild(1).gameObject.GetComponent<Animator>().Play("generate", 0, animationOffset * z);
			generators[z].transform.GetChild(1).gameObject.SetActive(isDouble);
        }
		
		generatorNumber_temp = generatorNumber;
		generatorSplits_temp = generatorSplits;
		isDouble_temp = isDouble;
	}
	
    // Update is called once per frame
    void Update()    {
        if(generatorNumber != generatorNumber_temp || generatorSplits != generatorSplits_temp || isDouble != isDouble_temp){
			create_generator();
		}
    }
}
